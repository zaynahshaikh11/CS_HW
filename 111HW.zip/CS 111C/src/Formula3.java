public class Formula3 
{
	public static int power3(int n)
	{
		if (n == 0)
		{
			return 1;
		}
		else 
		{
			// return x * x^(n-1)
		}
		return n;
	}
	
	public static void main (String [] args)
	{
//		System.out.println()
	}
	
}
