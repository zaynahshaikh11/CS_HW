public class TripleCallCounter 
{
	public static int solveTripleCounter(int n)
	{
		if (n == 0)
		{
			return 0;
		} else if (n == 1)
		{
			return 1;
		}
		else
		{
			return 1+ 2*solveTripleCounter(n-1);
		}
	}
	
	public static void main (String[] args)
	{
		System.out.println(solveTripleCounter(3));
		System.out.println(solveTripleCounter(4));
		System.out.println(solveTripleCounter(5));
	}


}
